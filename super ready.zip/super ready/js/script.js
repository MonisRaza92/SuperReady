

window.addEventListener('load', () => {
  setTimeout(() => {
    const preloader = document.querySelector('.preloader');
    preloader.style.transition = "transform 1s ease, opacity 0.5s ease";
    preloader.style.transform = "translateY(-100%)";

    setTimeout(() => {
      preloader.style.display = "none";
    }, 1000); // Wait for the slide up animation to finish
  }, 1500); // Delay of 1 second before starting slide up
});
/* ////PRELOADER END HERE*/


/* ////STICKY NAVBAR STARTS HERE*/
const target = document.getElementById('navbar');
let lastScroll = 0;

window.addEventListener('scroll', () => {
  let currentScroll = window.scrollY;
  if (currentScroll === 0) {
        target.classList.remove('nav-active')
  }
  else if (currentScroll > lastScroll) {
    target.classList.remove('nav-active');
    target.classList.add('nav-hide');
  } else {
    target.classList.remove('nav-hide');
    target.classList.add('nav-active');
  }

  lastScroll = currentScroll;
});

/* //////HAMBURGER FUNCTION START*/
const hamburger = document.querySelector('#hamburger');
const links = document.querySelectorAll('.nav-link a');
const navLink = document.querySelector('.nav-link');

hamburger.addEventListener('change', () => {
  if (hamburger.checked) {
    navLink.classList.add('nav-link-show');

    setTimeout(() => {
      links.forEach(tag => tag.classList.add('nav-link-open'));
    }, 500);
  } else {
    links.forEach(tag => tag.classList.remove('nav-link-open'));

    setTimeout(() => {
      navLink.classList.remove('nav-link-show');
    }, 500);
  }
});
/* //BOOKING SECTION JS*/
if (window.location.pathname.endsWith('index.html') || window.location.pathname === '/' || window.location.pathname === '/index') {
  

const bookNowBtn = document.getElementById('bookNowBtn');
const scheduleBtn = document.getElementById('scheduleBtn');
const scheduleFields = document.getElementById('scheduleFields');
const bookingForm = document.getElementById('bookingForm');
const confirmationDiv = document.getElementById('confirmation');
const dateInput = document.getElementById('date');
const timeInput = document.getElementById('time');


  bookNowBtn.addEventListener('click', () => {
  scheduleFields.style.display = 'none';
  scheduleBtn.classList.remove('button-active');
  bookNowBtn.classList.add('button-active');

  dateInput.disabled = true;
  dateInput.removeAttribute('required');
  
  timeInput.disabled = true;
  timeInput.removeAttribute('required');
});

scheduleBtn.addEventListener('click', () => {
  scheduleFields.style.display = 'block';
  scheduleBtn.classList.add('button-active');
  bookNowBtn.classList.remove('button-active');

  dateInput.disabled = false;
  dateInput.setAttribute('required', 'true');
  
  timeInput.disabled = false;
  timeInput.setAttribute('required', 'true');
});


bookingForm.addEventListener('submit', (e) => {
  e.preventDefault();

  const pickup = document.getElementById('pickup').value;
  const drop = document.getElementById('drop').value;
  const name = document.getElementById('name').value;
  const phone = document.getElementById('phone').value;
  const category = document.getElementById('category').value;

  let confirmationText = `
    <h3>Booking Confirmed!</h3>
    <p><strong>Pickup:</strong> ${pickup}</p>
    <p><strong>Drop:</strong> ${drop}</p>
    <p><strong>Name:</strong> ${name}</p>
    <p><strong>Phone:</strong> ${phone}</p>
    <p><strong>Car Category:</strong> ${category}</p>
  `;

  if (scheduleFields.style.display === 'block') {
    const date = dateInput.value;
    const time = timeInput.value;
    confirmationText += `
      <p><strong>Date:</strong> ${date}</p>
      <p><strong>Time:</strong> ${time}</p>
    `;
  }

  bookingForm.style.display = "none";
  confirmationDiv.style.display = "block";
  confirmationDiv.innerHTML = confirmationText;
});

}

/* ////CARS CATEGORY SECTION JS*/
function filterCards(category, event) {
  const heading = document.getElementById('category-heading');
  const buttons = document.querySelectorAll('.category-buttons .btn');
  const allCards = document.querySelectorAll('.card-item');

  const isHomePage = window.location.pathname.includes("index") || window.location.pathname === "/";

  // Hide all cards
  allCards.forEach(card => card.style.display = 'none');

  let count = 0;

  allCards.forEach(card => {
    const cat = card.getAttribute('data-category');

    // index page par sirf 3 cards, baaki pages par sabhi
    if ((category === 'all' || cat === category) && (isHomePage ? count < 3 : true)) {
      card.style.display = 'block';
      count++;
    }
  });

  heading.innerText = category === 'all' ? 'All Vehicles' : category.charAt(0).toUpperCase() + category.slice(1);

  if (event && event.currentTarget) {
    buttons.forEach(btn => btn.classList.remove('btn-active'));
    event.currentTarget.classList.add('btn-active');
  }
}

window.addEventListener('DOMContentLoaded', function () {
  const isValidPage = window.location.pathname.includes("index") || 
                      window.location.pathname.includes("vehicles") || 
                      window.location.pathname === "/";

  if (isValidPage) {
    const defaultBtn = document.querySelector('.btn.btn-active');
    if (defaultBtn) {
      filterCards('all', { currentTarget: defaultBtn });
    } else {
      filterCards('all');
    }
  }
});
    

/* || || || || FORM SUBMITION */
  function handleFormSubmit(event) {
    event.preventDefault();

    // Hide form
    const form = document.querySelector('.contact-form');
    form.style.display = 'none';

    // Show thank you message
    const message = document.getElementById('form-message');
    message.style.display = 'block';

    return false;
  }
  


/* //////ESTIMATE CALCULATION FUNCTION*/

